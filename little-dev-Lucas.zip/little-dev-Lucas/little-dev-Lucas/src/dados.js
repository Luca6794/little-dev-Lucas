let equipamentos = JSON.parse(localStorage.getItem('equipamentos')) || [];
let emprestimos = JSON.parse(localStorage.getItem('emprestimos')) || [];

function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    document.getElementById(sectionId).classList.add('active');
    const activeBtn = document.querySelector(`[data-section="${sectionId}"]`);
    if (activeBtn) activeBtn.classList.add('active');
}

function showValidationMessage(message, type) {
    const messageDiv = document.getElementById('validation-message');
    if (!messageDiv) return;
    
    messageDiv.textContent = message;
    messageDiv.className = `validation-message ${type}`;
    messageDiv.classList.remove('hidden');
    
    setTimeout(() => {
        messageDiv.classList.add('hidden');
    }, 5000);
}

function hideValidationMessage() {
    const messageDiv = document.getElementById('validation-message');
    if (messageDiv) {
        messageDiv.classList.add('hidden');
    }
}

const darkModeToggle = document.getElementById('toggle-dark-mode');
const isDarkMode = localStorage.getItem('darkMode') === 'true';

if (isDarkMode) {
    document.body.classList.add('dark-mode');
    darkModeToggle.checked = true;
}

darkModeToggle.addEventListener('change', () => {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
});

document.querySelectorAll('input[name="language"]').forEach(radio => {
    if (radio.value === currentLanguage) {
        radio.checked = true;
    }
    
    radio.addEventListener('change', (e) => {
        setLanguage(e.target.value);
    });
});

document.querySelectorAll('.nav-btn[data-section]').forEach(btn => {
    btn.addEventListener('click', () => {
        const section = btn.getAttribute('data-section');
        showSection(section);
    });
});

document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => {
        document.getElementById('modal-editar').classList.remove('active');
        document.getElementById('modal-devolucao').classList.remove('active');
    });
});

document.getElementById('modal-editar').addEventListener('click', (e) => {
    if (e.target.id === 'modal-editar') {
        document.getElementById('modal-editar').classList.remove('active');
    }
});

document.getElementById('modal-devolucao').addEventListener('click', (e) => {
    if (e.target.id === 'modal-devolucao') {
        document.getElementById('modal-devolucao').classList.remove('active');
    }
});

document.addEventListener('DOMContentLoaded', () => {
    updatePageTranslations();
    updateStats();
    renderEquipamentosTable();
    renderEmprestimosAtivosPreview();
    renderDevolucoesFinalizadasPreview();
});
