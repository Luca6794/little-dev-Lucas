document.getElementById('form-cadastro').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const equipamento = {
        id: Date.now().toString(),
        codigo: formData.get('codigo'),
        tipo: formData.get('tipo'),
        marca: formData.get('marca'),
        categoria: formData.get('categoria'),
        status: formData.get('status'),
        local: formData.get('local'),
        fixo: formData.get('fixo') === 'on',
        condicoes: formData.get('condicoes') || '',
        danos: formData.get('danos') || '',
        observacoes: formData.get('observacoes') || ''
    };
    
    if (equipamentos.some(e => e.codigo === equipamento.codigo)) {
        showValidationMessage(translate('codigoJaExiste'), 'error');
        return;
    }
    
    equipamentos.push(equipamento);
    localStorage.setItem('equipamentos', JSON.stringify(equipamentos));
    
    showValidationMessage(translate('equipamentoCadastrado'), 'success');
    e.target.reset();
    updateStats();
    renderEquipamentosTable();
});

document.getElementById('btn-limpar').addEventListener('click', () => {
    document.getElementById('form-cadastro').reset();
});

document.getElementById('btn-voltar-cadastro').addEventListener('click', () => {
    showSection('dashboard');
});

function renderEquipamentosTable(filtro = '') {
    const tbody = document.querySelector('#tabela-equipamentos tbody');
    let lista = equipamentos;
    
    if (filtro) {
        lista = equipamentos.filter(eq => 
            eq.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
            eq.tipo.toLowerCase().includes(filtro.toLowerCase()) ||
            eq.marca.toLowerCase().includes(filtro.toLowerCase()) ||
            eq.categoria.toLowerCase().includes(filtro.toLowerCase())
        );
    }
    
    if (lista.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" class="empty-row">${translate('nenhumEquipamentoCadastrado')}</td></tr>`;
        return;
    }
    
    tbody.innerHTML = lista.map(eq => `
        <tr>
            <td>${eq.codigo}</td>
            <td>${eq.tipo}</td>
            <td>${eq.marca}</td>
            <td>${eq.categoria}</td>
            <td><span class="status-badge status-${getStatusClass(eq.status)}">${translate(getStatusKey(eq.status))}</span></td>
            <td>${eq.local}</td>
            <td>${eq.fixo ? translate('sim') : translate('nao')}</td>
            <td>${eq.condicoes || '-'}</td>
            <td>${eq.danos || '-'}</td>
            <td>${eq.observacoes || '-'}</td>
            <td>
                <button class="btn btn-small btn-secondary" onclick="editarEquipamento('${eq.id}')">
                    ${translate('editar')}
                </button>
                <button class="btn btn-small btn-tertiary" onclick="excluirEquipamento('${eq.id}')">
                    ${translate('excluir')}
                </button>
            </td>
        </tr>
    `).join('');
}

document.getElementById('filtro-equipamentos').addEventListener('input', (e) => {
    renderEquipamentosTable(e.target.value);
});

function getStatusClass(status) {
    if (status === 'Disponível') return 'disponivel';
    if (status === 'Emprestado') return 'emprestado';
    if (status === 'Em manutenção') return 'manutencao';
    return 'disponivel';
}

function getStatusKey(status) {
    if (status === 'Disponível') return 'disponivel';
    if (status === 'Emprestado') return 'emprestado';
    if (status === 'Em manutenção') return 'manutencao';
    return 'disponivel';
}

function editarEquipamento(id) {
    const equipamento = equipamentos.find(e => e.id === id);
    if (!equipamento) return;
    
    document.getElementById('edit-id').value = equipamento.id;
    document.getElementById('edit-codigo').value = equipamento.codigo;
    document.getElementById('edit-tipo').value = equipamento.tipo;
    document.getElementById('edit-marca').value = equipamento.marca;
    document.getElementById('edit-categoria').value = equipamento.categoria;
    document.getElementById('edit-status').value = equipamento.status;
    document.getElementById('edit-local').value = equipamento.local;
    document.getElementById('edit-fixo').checked = equipamento.fixo;
    document.getElementById('edit-condicoes').value = equipamento.condicoes || '';
    document.getElementById('edit-danos').value = equipamento.danos || '';
    document.getElementById('edit-observacoes').value = equipamento.observacoes || '';
    
    document.getElementById('modal-editar').classList.add('active');
}

document.getElementById('form-editar').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const id = document.getElementById('edit-id').value;
    const equipamento = equipamentos.find(e => e.id === id);
    if (!equipamento) return;
    
    equipamento.codigo = document.getElementById('edit-codigo').value;
    equipamento.tipo = document.getElementById('edit-tipo').value;
    equipamento.marca = document.getElementById('edit-marca').value;
    equipamento.categoria = document.getElementById('edit-categoria').value;
    equipamento.status = document.getElementById('edit-status').value;
    equipamento.local = document.getElementById('edit-local').value;
    equipamento.fixo = document.getElementById('edit-fixo').checked;
    equipamento.condicoes = document.getElementById('edit-condicoes').value;
    equipamento.danos = document.getElementById('edit-danos').value;
    equipamento.observacoes = document.getElementById('edit-observacoes').value;
    
    localStorage.setItem('equipamentos', JSON.stringify(equipamentos));
    
    document.getElementById('modal-editar').classList.remove('active');
    renderEquipamentosTable();
    updateStats();
    showValidationMessage(translate('equipamentoAtualizado'), 'success');
});

function excluirEquipamento(id) {
    if (!confirm(translate('confirmarExclusao'))) return;
    
    equipamentos = equipamentos.filter(e => e.id !== id);
    localStorage.setItem('equipamentos', JSON.stringify(equipamentos));
    
    renderEquipamentosTable();
    updateStats();
    showValidationMessage(translate('equipamentoExcluido'), 'success');
}
