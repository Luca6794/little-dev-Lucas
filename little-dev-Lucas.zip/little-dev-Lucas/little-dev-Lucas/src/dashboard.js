function updateStats() {
    const totalEquipamentos = equipamentos.length;
    const emprestimosAtivos = emprestimos.filter(e => !e.dataDevolucao).length;
    const equipamentosDisponiveis = equipamentos.filter(e => e.status === 'Disponível').length;
    const equipamentosManutencao = equipamentos.filter(e => e.status === 'Em manutenção').length;
    
    document.getElementById('stat-total-equipamentos').textContent = totalEquipamentos;
    document.getElementById('stat-emprestimos-ativos').textContent = emprestimosAtivos;
    document.getElementById('stat-equipamentos-disponiveis').textContent = equipamentosDisponiveis;
    document.getElementById('stat-equipamentos-manutencao').textContent = equipamentosManutencao;
    
    renderRecentLoans();
}

function renderRecentLoans() {
    const container = document.getElementById('recent-loans-container');
    const recent = emprestimos.filter(e => !e.dataDevolucao).slice(0, 3);
    
    if (recent.length === 0) {
        container.innerHTML = `<p class="empty-state">${translate('nenhumEmprestimoRegistrado')}</p>`;
        return;
    }
    
    container.innerHTML = recent.map(emp => {
        const equip = equipamentos.find(e => e.codigo === emp.codigo);
        return `
            <div class="recent-loan-item">
                <div class="loan-info">
                    <span class="loan-label">${translate('codigo')}</span>
                    <span class="loan-value">${emp.codigo}</span>
                </div>
                <div class="loan-info">
                    <span class="loan-label">${translate('item')}</span>
                    <span class="loan-value">${equip ? equip.tipo : '-'}</span>
                </div>
                <div class="loan-info">
                    <span class="loan-label">${translate('solicitante')}</span>
                    <span class="loan-value">${emp.solicitante}</span>
                </div>
                <div class="loan-info">
                    <span class="loan-label">${translate('prazoDevolucao')}</span>
                    <span class="loan-value">${formatDateTime(emp.prazoDevolucao)}</span>
                </div>
            </div>
        `;
    }).join('');
}
