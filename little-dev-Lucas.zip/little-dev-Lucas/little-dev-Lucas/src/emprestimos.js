document.getElementById('emp-codigo').addEventListener('input', (e) => {
    const codigo = e.target.value.trim();
    const equipamento = equipamentos.find(eq => eq.codigo === codigo);
    const itemInput = document.getElementById('emp-item');
    const danosInput = document.getElementById('emp-danos');
    
    if (equipamento) {
        itemInput.value = `${equipamento.tipo} - ${equipamento.marca}`;
        danosInput.value = equipamento.danos || '';
    } else {
        itemInput.value = '';
        danosInput.value = '';
    }
});

document.getElementById('form-emprestimo').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const codigo = formData.get('codigo');
    
    const equipamento = equipamentos.find(eq => eq.codigo === codigo);
    if (!equipamento) {
        showValidationMessage(translate('equipamentoNaoEncontrado'), 'error');
        return;
    }
    
    if (equipamento.status === 'Emprestado' || equipamento.status === 'Em manutenção') {
        showValidationMessage(`${translate('equipamentoIndisponivel')} ${equipamento.status}`, 'error');
        return;
    }
    
    const emprestimo = {
        id: Date.now().toString(),
        codigo: codigo,
        item: formData.get('item'),
        solicitante: formData.get('solicitante'),
        dataEmprestimo: formData.get('dataEmprestimo'),
        prazoDevolucao: formData.get('prazoDevolucao'),
        danos: formData.get('danos') || '',
        dataDevolucao: null,
        danosNaDevolucao: ''
    };
    
    emprestimos.push(emprestimo);
    localStorage.setItem('emprestimos', JSON.stringify(emprestimos));
    
    equipamento.status = 'Emprestado';
    localStorage.setItem('equipamentos', JSON.stringify(equipamentos));
    
    showValidationMessage(translate('emprestimoRegistrado'), 'success');
    e.target.reset();
    updateStats();
    renderEmprestimosAtivosPreview();
    renderEquipamentosTable();
});

document.getElementById('btn-limpar-emprestimo').addEventListener('click', () => {
    document.getElementById('form-emprestimo').reset();
    hideValidationMessage();
});

function renderEmprestimosAtivosPreview() {
    const container = document.getElementById('emprestimos-ativos-preview');
    const ativos = emprestimos.filter(e => !e.dataDevolucao).slice(0, 3);
    
    if (ativos.length === 0) {
        container.innerHTML = `
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>${translate('codigo')}</th>
                            <th>${translate('item')}</th>
                            <th>${translate('solicitante')}</th>
                            <th>${translate('dataEmprestimo')}</th>
                            <th>${translate('prazoDevolucao')}</th>
                            <th>${translate('danos')}</th>
                            <th>${translate('acoes')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td colspan="7" class="empty-row">${translate('nenhumEmprestimoAtivo')}</td></tr>
                    </tbody>
                </table>
            </div>
        `;
        return;
    }
    
    container.innerHTML = `
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>${translate('codigo')}</th>
                        <th>${translate('item')}</th>
                        <th>${translate('solicitante')}</th>
                        <th>${translate('dataEmprestimo')}</th>
                        <th>${translate('prazoDevolucao')}</th>
                        <th>${translate('danos')}</th>
                        <th>${translate('acoes')}</th>
                    </tr>
                </thead>
                <tbody>
                    ${ativos.map(emp => `
                        <tr>
                            <td>${emp.codigo}</td>
                            <td>${emp.item}</td>
                            <td>${emp.solicitante}</td>
                            <td>${formatDateTime(emp.dataEmprestimo)}</td>
                            <td>${formatDateTime(emp.prazoDevolucao)}</td>
                            <td>${emp.danos || '-'}</td>
                            <td>
                                <button class="btn btn-small btn-primary" onclick="mostrarModalDevolucao('${emp.id}')">
                                    ${translate('devolver')}
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function renderDevolucoesFinalizadasPreview() {
    const container = document.getElementById('devolucoes-finalizadas-preview');
    const finalizados = emprestimos.filter(e => e.dataDevolucao).slice(0, 3);
    
    if (finalizados.length === 0) {
        container.innerHTML = `
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>${translate('codigo')}</th>
                            <th>${translate('item')}</th>
                            <th>${translate('solicitante')}</th>
                            <th>${translate('dataEmprestimo')}</th>
                            <th>${translate('prazoDevolucao')}</th>
                            <th>${translate('dataDevolucao')}</th>
                            <th>${translate('danos')}</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><td colspan="7" class="empty-row">${translate('nenhemDevolucaoFinalizada')}</td></tr>
                    </tbody>
                </table>
            </div>
        `;
        return;
    }
    
    container.innerHTML = `
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>${translate('codigo')}</th>
                        <th>${translate('item')}</th>
                        <th>${translate('solicitante')}</th>
                        <th>${translate('dataEmprestimo')}</th>
                        <th>${translate('prazoDevolucao')}</th>
                        <th>${translate('dataDevolucao')}</th>
                        <th>${translate('danos')}</th>
                    </tr>
                </thead>
                <tbody>
                    ${finalizados.map(emp => `
                        <tr>
                            <td>${emp.codigo}</td>
                            <td>${emp.item}</td>
                            <td>${emp.solicitante}</td>
                            <td>${formatDateTime(emp.dataEmprestimo)}</td>
                            <td>${formatDateTime(emp.prazoDevolucao)}</td>
                            <td>${formatDateTime(emp.dataDevolucao)}</td>
                            <td>${emp.danosNaDevolucao || emp.danos || '-'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

document.getElementById('btn-ver-todos-ativos').addEventListener('click', () => {
    showSection('emprestimos-ativos-expandido');
    renderEmprestimosAtivosExpandido();
});

document.getElementById('btn-voltar-ativos').addEventListener('click', () => {
    showSection('emprestimos');
});

function renderEmprestimosAtivosExpandido(filtro = '') {
    const tbody = document.querySelector('#tabela-ativos-expandido tbody');
    let ativos = emprestimos.filter(e => !e.dataDevolucao);
    
    if (filtro) {
        ativos = ativos.filter(emp => 
            emp.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
            emp.item.toLowerCase().includes(filtro.toLowerCase()) ||
            emp.solicitante.toLowerCase().includes(filtro.toLowerCase())
        );
    }
    
    if (ativos.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-row">${translate('nenhumEmprestimoAtivo')}</td></tr>`;
        return;
    }
    
    tbody.innerHTML = ativos.map(emp => `
        <tr>
            <td>${emp.codigo}</td>
            <td>${emp.item}</td>
            <td>${emp.solicitante}</td>
            <td>${formatDateTime(emp.dataEmprestimo)}</td>
            <td>${formatDateTime(emp.prazoDevolucao)}</td>
            <td>${emp.danos || '-'}</td>
            <td>
                <button class="btn btn-small btn-primary" onclick="mostrarModalDevolucao('${emp.id}')">
                    ${translate('devolver')}
                </button>
            </td>
        </tr>
    `).join('');
}

document.getElementById('filtro-ativos-expandido').addEventListener('input', (e) => {
    renderEmprestimosAtivosExpandido(e.target.value);
});

document.getElementById('btn-ver-todos-finalizados').addEventListener('click', () => {
    showSection('devolucoes-finalizadas-expandido');
    renderDevolucoesFinalizadasExpandido();
});

document.getElementById('btn-voltar-finalizados').addEventListener('click', () => {
    showSection('emprestimos');
});

function renderDevolucoesFinalizadasExpandido(filtro = '') {
    const tbody = document.querySelector('#tabela-finalizados-expandido tbody');
    let finalizados = emprestimos.filter(e => e.dataDevolucao);
    
    if (filtro) {
        finalizados = finalizados.filter(emp => 
            emp.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
            emp.item.toLowerCase().includes(filtro.toLowerCase()) ||
            emp.solicitante.toLowerCase().includes(filtro.toLowerCase())
        );
    }
    
    if (finalizados.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-row">${translate('nenhemDevolucaoFinalizada')}</td></tr>`;
        return;
    }
    
    tbody.innerHTML = finalizados.map(emp => `
        <tr>
            <td>${emp.codigo}</td>
            <td>${emp.item}</td>
            <td>${emp.solicitante}</td>
            <td>${formatDateTime(emp.dataEmprestimo)}</td>
            <td>${formatDateTime(emp.prazoDevolucao)}</td>
            <td>${formatDateTime(emp.dataDevolucao)}</td>
            <td>${emp.danosNaDevolucao || emp.danos || '-'}</td>
        </tr>
    `).join('');
}

document.getElementById('filtro-finalizados-expandido').addEventListener('input', (e) => {
    renderDevolucoesFinalizadasExpandido(e.target.value);
});

function mostrarModalDevolucao(emprestimoId) {
    document.getElementById('dev-emprestimo-id').value = emprestimoId;
    document.getElementById('dev-danos').value = '';
    document.getElementById('modal-devolucao').classList.add('active');
}

document.getElementById('form-devolucao').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const emprestimoId = document.getElementById('dev-emprestimo-id').value;
    const danosNaDevolucao = document.getElementById('dev-danos').value.trim();
    
    devolverEquipamento(emprestimoId, danosNaDevolucao);
    
    document.getElementById('modal-devolucao').classList.remove('active');
});

function devolverEquipamento(emprestimoId, danosNaDevolucao = '') {
    const emprestimo = emprestimos.find(e => e.id === emprestimoId);
    if (!emprestimo) return;
    
    emprestimo.dataDevolucao = new Date().toISOString();
    emprestimo.danosNaDevolucao = danosNaDevolucao;
    localStorage.setItem('emprestimos', JSON.stringify(emprestimos));
    
    const equipamento = equipamentos.find(eq => eq.codigo === emprestimo.codigo);
    if (equipamento) {
        equipamento.status = 'Disponível';
        if (danosNaDevolucao) {
            equipamento.danos = danosNaDevolucao;
        }
        localStorage.setItem('equipamentos', JSON.stringify(equipamentos));
    }
    
    showValidationMessage(translate('devolucaoRegistrada'), 'success');
    updateStats();
    renderEmprestimosAtivosPreview();
    renderDevolucoesFinalizadasPreview();
    renderEmprestimosAtivosExpandido();
    renderDevolucoesFinalizadasExpandido();
    renderEquipamentosTable();
}
