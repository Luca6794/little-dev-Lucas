CREATE DATABASE IF NOT EXISTS `emprest_senai`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `emprest_senai`;

CREATE TABLE IF NOT EXISTS `equipamentos` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `codigo` VARCHAR(20) NOT NULL UNIQUE,
  `tipo` VARCHAR(100) NOT NULL,
  `marca` VARCHAR(100) NOT NULL,
  `categoria` VARCHAR(100) NOT NULL,
  `status_inicial` ENUM('Disponível', 'Emprestado', 'Em manutenção') DEFAULT 'Disponível',
  `local` ENUM('Sim', 'Não') DEFAULT 'Sim',
  `condicoes` VARCHAR(100),
  `danos` TEXT,
  `item_fixo` BOOLEAN DEFAULT FALSE,
  `observacoes` TEXT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `emprestimos` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `equipamento_id` INT NOT NULL,
  `solicitante` VARCHAR(150) NOT NULL,
  `data_emprestimo` DATETIME NOT NULL,
  `prazo_devolucao` DATETIME NOT NULL,
  `danos` TEXT,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_emprestimos_equipamento`
    FOREIGN KEY (`equipamento_id`)
    REFERENCES `equipamentos` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `devolucoes` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `emprestimo_id` INT NOT NULL,
  `data_devolucao` DATETIME NOT NULL,
  `danos` TEXT,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_devolucoes_emprestimo`
    FOREIGN KEY (`emprestimo_id`)
    REFERENCES `emprestimos` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `equipamentos` 
(`codigo`, `tipo`, `marca`, `categoria`, `status_inicial`, `local`, `condicoes`, `danos`, `item_fixo`, `observacoes`)
VALUES
('EQ001', 'Notebook', 'Dell', 'Informática', 'Disponível', 'Sim', 'Bom estado', NULL, TRUE, 'Usado em laboratório principal'),
('EQ002', 'Câmera', 'Canon', 'Audiovisual', 'Disponível', 'Não', 'Novo', NULL, FALSE, 'Para uso em eventos'),
('EQ003', 'Furadeira', 'Bosch', 'Elétrica', 'Emprestado', 'Sim', 'Regular', 'Pequenos arranhões', TRUE, 'Em uso na manutenção');

INSERT INTO `emprestimos` 
(`equipamento_id`, `solicitante`, `data_emprestimo`, `prazo_devolucao`, `danos`)
VALUES
(1, 'João Silva', '2025-10-25 10:00:00', '2025-10-30 17:00:00', NULL),
(2, 'Maria Souza', '2025-10-26 09:30:00', '2025-11-02 18:00:00', NULL),
(3, 'Carlos Lima', '2025-10-28 14:00:00', '2025-11-05 17:00:00', 'Arranhão no corpo do equipamento');

INSERT INTO `devolucoes` 
(`emprestimo_id`, `data_devolucao`, `danos`)
VALUES
(1, '2025-10-30 15:00:00', NULL),
(2, '2025-11-02 17:45:00', NULL),
(3, '2025-11-05 17:30:00', 'Mesmo arranhão relatado no empréstimo');
